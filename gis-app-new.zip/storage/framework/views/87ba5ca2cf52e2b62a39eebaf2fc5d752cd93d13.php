


<script type="text/javascript" src="<?php echo e(asset('vendor/jquery/jquery.min.js')); ?>"></script>     
<script type="text/javascript" src="<?php echo e(asset('vendor/jquery-ui/jquery-ui.min.js')); ?>"></script>     
<script type="text/javascript" src="<?php echo e(asset('vendor/jquery-ui/jquery.blockUI.js')); ?>"></script>       


<!-- Datatable -->
<script src="<?php echo e(asset('vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>

<script src="<?php echo e(asset('vendor/select2/js/select2.min.js')); ?>"></script>

<script src="<?php echo e(asset('vendor/jquery-validation/jquery.validate.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/jquery-validation/localization/messages_id.min.js')); ?>"></script>

<script src="<?php echo e(asset('vendor/jquery-validation/jquery.form.js')); ?>"></script>

<script src="<?php echo e(asset('vendor/sweetalert2/sweetalert2.min.js')); ?>"></script><?php /**PATH D:\Kuliah\Semester VI\GIS\gis-app-new\resources\views/admin/layouts_dashboard/metascript.blade.php ENDPATH**/ ?>