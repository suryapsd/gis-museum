 <?php $__env->startSection('content'); ?>
<div class="container-xxl flex-grow-1 container-p-y">
	
    <a href="/admin/museum/<?php echo e($data_galeri->museum_id); ?>/galeri" class="btn btn-outline-primary mb-3">
        <span class="tf-icons bx bx-left-arrow-alt"></span>&nbsp; Kembali
    </a>
    <script>
        <?php if(\Session::has('success')): ?>
          Swal.fire(
            'Success',
            '<?php echo \Session::get('success'); ?>',
            'success'
          )
        <?php elseif(\Session::has('error')): ?>
          Swal.fire(
            'Opps!',
            '<?php echo \Session::get('error'); ?>',
            'error'
          )
        <?php endif; ?> 
    </script>
	<div class="row">
		<!-- Basic Layout -->
		<div class="col-xxl">
			<div class="card mb-4">
				<div class="card-header d-flex align-items-center justify-content-between">
					<h5 class="mb-0">List <?php echo e($title); ?> Galeri <?php echo e($data_galeri->nama); ?></h5>
					<a href="/admin/galeri/<?php echo e($data_galeri->id); ?>/koleksi/create" class="btn btn-primary">
					    <span class="tf-icons bx bx-plus"></span>&nbsp; Tambah Data 
                    </a>
				</div>
				<div class="card-body">
                    <div class="table-responsive text-nowrap">
                        <table id="<?php echo e($table_id); ?>" class="table" style="width: 100%;">
                        <thead class="table-light">
                        <tr>
                            <th>No</th>
                            <th>Foto</th>
                            <th>Nama</th>
                            <th>Nama Seniman</th>
                            <th>Tahun Pembuatan</th>
                            <th>Deskripsi</th>
                            <th>Actions</th>
                        </tr>
                        </thead>
                        <tbody class="table-border-bottom-0">
                        </tbody>
                        </table>
                    </div>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- / Content -->
<!-- Modal Layout -->
<div class="modal fade" id="ajaxModel" data-bs-backdrop="static" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modelHeading">Modal title</h5>
                <button
                  type="button"
                  class="btn-close"
                  data-bs-dismiss="modal"
                  aria-label="Close"
                ></button>
            </div>
            <form action="/admin/koleksi/" id="modalForm" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <input type="text" hidden name="museum_id" id="museum_id" value="">
                    <div class="row">
                        <label class="form-label" for="basic-default-name">Foto Koleksi <span style="color: red">*</span></label>
							<div class="input-group">
                                <input type='file' class="form-control <?php $__errorArgs = ['image_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="image_name[]" id="image_name" multiple accept=".png, .jpg, .jpeg" />
                                <label class="input-group-text" for="image_name">Choose images</label>
                                <?php $__errorArgs = ['image_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                    </div>
                </div>
                <div class="modal-footer">
                      <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                        Close
                      </button>
                      <button type="submit" class="btn btn-primary" id="saveBtn" value="create">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>
<!-- Modal -->
<?php $__env->startPush('script'); ?>
<script type="text/javascript">
var table;
$(document).ready(function() {
    table = $('#<?php echo e($table_id); ?>').DataTable({
        
        "language": {
            "lengthMenu": "_MENU_",
            /* 'loadingRecords': '&nbsp;',
            'processing': '<img src="<?php echo e(asset('assets/img/loader-sm.gif')); ?>"/>' */
        },
        processing:true,
        autoWidth: true,
        ordering: true,
        serverSide: true,
        ajax: {
            url: '<?php echo e(url("museum/ajaxKoleksi")); ?>/' + <?php echo e($data_galeri->id); ?>,
            type:"POST",
            data: function(params) {
                params._token = "<?php echo e(csrf_token()); ?>";
            }
        },
        
        language: {
            search: "",
            searchPlaceholder: "Type in to Search",
            lengthMenu: "<div class='d-flex justify-content-start form-control-select'> _MENU_ </div>",
            // info: "_START_ -_END_ of _TOTAL_",
            info: "Menampilkan _START_ sampai _END_ dari _TOTAL_",
            infoEmpty: "No records found",
            infoFiltered: "( Total _MAX_  )",
            paginate: {
              "first": "First",
              "last": "Last",
              "next": "Next",
              "previous": "Prev"
            }
        },
        columns: [
            { data: 'DT_RowIndex', name: 'DT_RowIndex', orderable: false, searchable: false, class: 'text-left' },    
            {   data: 'image_koleksi', 
                name: 'image_koleksi',
                title: "Image",
                orderable: false,
                searchable: false,
                class: 'text-center'
            },
            {
                data: 'nama',
                name: 'nama',
                orderable: true,
                searchable: true,
                class: 'text-left'
            },
            {
                data: 'artist',
                name: 'artist',
                orderable: false,
                searchable: true,
                class: 'text-left'
            },
            {
                data: 'formatted_date',
                name: 'formatted_date',
                orderable: true,
                searchable: true,
                class: 'text-center'
            },
            {
                data: 'description',
                name: 'description',
                orderable: true,
                searchable: true,
                class: 'text-left'
            },
            {
                data: 'action',
                name: 'id',
                orderable: false,
                searchable: false,
                class: 'text-center'
            }
        ]
    });
    
    $("#<?php echo e($table_id); ?>").DataTable().processing(true);
    $('#<?php echo e($table_id); ?>_filter input').unbind();
    $('#<?php echo e($table_id); ?>_filter input').bind('keyup', function(e) {
        if(e.keyCode == 13) {
            table.search(this.value).draw();   
        }
    });
    $('.dataTables_filter').html('<div class="input-group flex-nowrap"><span class="input-group-text" id="addon-wrapping"><i class="bi bi-search"></i></span><input type="search" class="form-control form-control-sm" placeholder="Type in to Search" aria-label="Type in to Search" aria-describedby="addon-wrapping"></div>');
});

function addData(id){
        document.getElementById("modalForm").action += id + "/koleksi-images";
        document.getElementById("galeri_id").value = id;
        $('#saveBtn').val("create-koleksi");
        $('#data_id').val('');
        $('#modalForm').trigger("reset");
        $('#modelHeading').html("Tambah Foto Koleksi");
        $('#ajaxModel').modal('show');
    }

function deleteData(id){
    CustomSwal.fire({
        icon:'warning',
        text: 'Hapus Data Koleksi?',
        showCancelButton: true,
        confirmButtonText: 'Hapus',
        cancelButtonText: 'Batal',
    }).then((result) => {
        /* Read more about isConfirmed, isDenied below */
        if (result.isConfirmed) {
            $.ajax({
                url:"<?php echo e(url('/admin/galeri/')); ?>/" + <?php echo e($data_galeri->id); ?> + "/koleksi/" + id,
                data:{
                    _method:"DELETE",
                    _token:"<?php echo e(csrf_token()); ?>"
                },
                type:"POST",
                dataType:"JSON",
                beforeSend:function(){
                    block("#<?php echo e($table_id); ?>");
                },
                success:function(data){
                    if(data.success == 1){
                        Swal.fire('Sukses', data.msg, 'success');
                    }else{
                        Swal.fire('Gagal', data.msg, 'error');
                    }
                    unblock("#<?php echo e($table_id); ?>");
                    RefreshTable('<?php echo e($table_id); ?>',0);
                },
                error:function(error){
                    Swal.fire('Gagal', 'terjadi kesalahan sistem', 'error');
                    console.log(error.XMLHttpRequest);
                    unblock("#<?php echo e($table_id); ?>");
                    RefreshTable('<?php echo e($table_id); ?>',0);
                }
            });
        }
    });
}
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts_dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Semester VI\GIS\gis-app-new\resources\views/admin/koleksi/index.blade.php ENDPATH**/ ?>